#include <avr/io.h>
#include <util/delay.h>
#include "lcd.h"

int main()
{
     LCDInit(0);// pass 1 for cursor blinking 
    LCDClear();
    //LCDGotoXY(0,0);
	//LCDWriteStringXY(x,y,msg);

	LCDWriteString("hello");
	LCDWriteInt(value,length);
    while(1)
    {
       
    }
	

}
