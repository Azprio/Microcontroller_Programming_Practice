#include<avr/io.h>
#include<util/delay.h>
#include<lcd.h>

main(){
	DDRA = 0b01111111;
	char msg[] = "Hello MCU-2";
	int len = sizeof(msg);
	for(int i = 0 ; i<len-1 ; i++){
		PORTA = msg[i];
		while(!(PINA&(1<<PA7))){
			
		}
		_delay_ms(1);
	}
	
	PORTA |= 0b01111111;
}