#include<avr/io.h>
#include<util/delay.h>
#include<lcd.h>

main(){
	char c[16];
	DDRC = 0b10000000;
	LCDInit(0);// pass 1 for cursor blinking 
    LCDClear();
	int i = 0;
	while(1){
		c[i] = PINC;
		PORTC |= (1<<7);
		_delay_ms(1);
		PORTC &= ~(1<<7);
		_delay_ms(1);
		i++;
		if(PINC == 0b01111111){break;}
	}
		//c[0] = PINC;
		LCDWriteString(c);
}